#include <windows.h>

HRGN BmpToRgn (HBITMAP, COLORREF);


HRGN BmpToRgn (HBITMAP hBmp, COLORREF cTransparentColor)
{
#define ALLOC_UNIT 100
	HRGN HCombinedRgn = NULL;
	if (!hBmp) return 0; // si bitmap invalide retourne
	BITMAP bitmap;
	GetObject(hBmp, sizeof(bitmap), &bitmap); // met les infos d'en tete du bitmap dans bitmap
	UINT sizeimage=bitmap.bmWidth*bitmap.bmHeight*4; // enregistre la taille des donnes de l'image
	char *lpBmpBits=(char*)LocalAlloc(LMEM_FIXED,sizeimage); // fait de la place pour les bits du bitmap
	GetBitmapBits(hBmp,sizeimage,lpBmpBits); // obtient les bits de l'image dans l'espace qu'on a reserv�
	bitmap.bmBits=lpBmpBits; // complete la strucutre bm avec les bits
	while (bitmap.bmWidthBytes % 4) bitmap.bmWidthBytes++; // bmWidthBytes doit �tre divisible par 4

	DWORD maxRects = ALLOC_UNIT;
	HANDLE hData = GlobalAlloc(GMEM_MOVEABLE, sizeof(RGNDATAHEADER) + (sizeof(RECT) * maxRects));
	RGNDATA *pData = (RGNDATA *)GlobalLock(hData);
	pData->rdh.dwSize = sizeof(RGNDATAHEADER);
	pData->rdh.iType = RDH_RECTANGLES;
	pData->rdh.nCount = pData->rdh.nRgnSize = 0;
	SetRect(&pData->rdh.rcBound, MAXLONG, MAXLONG, 0, 0);

	BYTE *p32 = (BYTE *)bitmap.bmBits;
	for (int ligne = 0; ligne < bitmap.bmHeight; ligne++) // parcourt toutes les lignes de l'image, de haut en bas
	{
		for (int xpixel = 0; xpixel < bitmap.bmWidth; xpixel++) // parcourt tous les pixels de la ligne, de gauche � droite
		{
			// Recherche une suite continue de pixels non transparents
			int x0 = xpixel;
			LONG *p = (LONG *)(p32 + 4*xpixel);
			while (xpixel < bitmap.bmWidth)
			{
				if ((unsigned)*p==cTransparentColor)
					break; // ce pixel est transparent
				p++;
				xpixel++;
			}
			if (xpixel > x0)
			{
				// ajoute les pixels (de (x0, ligne) � (x, ligne+1)) � la region en tant que rectangle
				if (pData->rdh.nCount >= maxRects)
				{
					GlobalUnlock(hData);
					maxRects += ALLOC_UNIT;
					hData = GlobalReAlloc(hData, sizeof(RGNDATAHEADER) + 
						(sizeof(RECT) * maxRects), GMEM_MOVEABLE);
					pData = (RGNDATA *)GlobalLock(hData);
				}
				RECT *pr = (RECT *)&pData->Buffer;
				SetRect(&pr[pData->rdh.nCount], x0, ligne, xpixel, ligne+1);
				if (x0 < pData->rdh.rcBound.left)
					pData->rdh.rcBound.left = x0;
				if (ligne < pData->rdh.rcBound.top)
					pData->rdh.rcBound.top = ligne;
				if (xpixel > pData->rdh.rcBound.right)
					pData->rdh.rcBound.right = xpixel;
				if (ligne+1 > pData->rdh.rcBound.bottom)
					pData->rdh.rcBound.bottom = ligne+1;
				pData->rdh.nCount++;

				// Il parait que sous Windows 98, ExtCreateRegion() ne marche pas s'il ligne a trop de rectangles
				// Pas de panique: on construit la region en deux fois
				if (pData->rdh.nCount == 2000)
				{
					HRGN h = ExtCreateRegion(NULL, sizeof(RGNDATAHEADER) + (sizeof(RECT) * maxRects), pData);
					if (HCombinedRgn)
					{
						CombineRgn(HCombinedRgn, HCombinedRgn, h, RGN_OR);
						DeleteObject(h);
					}
					else
						HCombinedRgn = h;
					pData->rdh.nCount = 0;
					SetRect(&pData->rdh.rcBound, MAXLONG, MAXLONG, 0, 0);
				}
			}
		}
		// On passe � la ligne suivante
		p32 += bitmap.bmWidthBytes;
	}
	// On cree la region
	// (et, s'il ligne avait plus de 2000 rectangles, on la combine avec celle  cr�ee precedemment)
	HRGN hCreatedRegion = ExtCreateRegion(NULL, sizeof(RGNDATAHEADER) + (sizeof(RECT) * maxRects), pData);
	if (HCombinedRgn)
	{
		CombineRgn(HCombinedRgn, HCombinedRgn, hCreatedRegion, RGN_OR);
		DeleteObject(hCreatedRegion);
	}
	else HCombinedRgn = hCreatedRegion;
	LocalFree((HLOCAL)lpBmpBits);
	return HCombinedRgn;
}

